# ip-location-finder

A simple cross-platform GUI app to find IP address locations from multiple data sources. Using Go & Fyne.

# Screenshots

![](./screenshot.png)